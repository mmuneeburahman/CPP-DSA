#include <iostream>
#include <cmath>
using namespace std;

template <typename T>
class pqueue {
	int m_capacity;
	int m_counter;
	T* m_data;
	//Function That Arrange the Tree After Adding Value;
	//Move the Added value up if the greater than the parent.
	void bubbleUp() {
		int temperoryCounter = m_counter;
		while (
			(temperoryCounter > 1)
			&& 
			(m_data[temperoryCounter] > m_data[temperoryCounter / 2])) {
			swap(m_data[temperoryCounter], m_data[temperoryCounter / 2]);
			temperoryCounter /= 2;
		}
	}
	//Function that arrange the Tree after removing value;
	//Move the root down if it is smaller than its child.
	void bubbleDown() {
		int counter = 1;
		while (true) {
			if (2*counter<m_counter 
				&& 
				m_data[counter] < m_data[2 * counter]
				&&
				m_data[2*counter]>m_data[2*counter+1]) {
				swap(m_data[counter], m_data[2 * counter]);
				counter *= 2;
			}
			else if (
				(2*counter+1<m_counter) 
				&&
				m_data[counter] < m_data[2 * counter + 1]) {
				swap(m_data[counter], m_data[2 * counter + 1]);
				counter = 2 * counter + 1;
			}
			else
				break;
		}
	}
public:
	pqueue(int capacity):m_capacity(capacity){
		m_data = new T[m_capacity];
		m_counter = 1;
	}
	void add(T value) {
		m_data[m_counter] = value;
		bubbleUp();
		m_counter++;
	}
	void remove() {
		m_data[1] = m_data[m_counter-1];
		--m_counter;
		bubbleDown();
		
	}
	friend ostream& operator<<(ostream&, const pqueue<T>& c) {
		int level = -1;
		for (int i = 1; i < c.m_counter; ++i) {
			if (i == 1 || floor(log2(i)) > level) {
				cout << endl;
				for (int j = 0; j < c.m_capacity - 2 * i; ++j)
					cout << " ";
				++level;
			}
			cout << c.m_data[i];
			for (int j = 0; j < 2 * level; ++j)
				cout << " ";
		}
		return cout;
	}
};

int main() {
	pqueue<int> pq(8);
	pq.add(10);
	pq.add(5);
	pq.add(3);
	pq.add(1);
	pq.add(1);
	pq.add(1);
	pq.add(1);
	cout << pq << endl;
	pqueue<int> pq1(16);
	for(int i = 14; i > 0; --i)
		pq1.add(i * 2);
	cout << pq1 << endl;

	cout << "\n\n\tAfter Adding 100" << endl;
	pq1.add(100);
	cout << pq1 << endl;

	for (int i = 0; i < 4; i++) {
		pq1.remove();
		cout << pq1 << endl;
	}
	return 0;
}