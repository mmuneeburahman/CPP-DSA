#include <iostream>
using namespace std;
template <typename T>
class MinMaxHeap {
	size_t m_capacity;
	size_t m_size;
	T* m_data;
	int levelnumber(int node) {
		return log2(node);
	}
	bool isMinLevel(int node) {
		return (levelnumber(node) % 2 == 0);
	}
	void bubbleUp(int node, bool isMinLevel) {
		while (true) {
			if (isMinLevel) {
				if (m_data[node] < m_data[node /4 ]) {
					swap(m_data[node], m_data[node / 4]);
					node /= 4;
				}
				else return;
			}
			else {
				if (node > 3 && m_data[node] > m_data[node / 4]) {
					swap(m_data[node], m_data[node / 4]);
					node /= 4;
				}
				else return;
			}
		}
	}
public:
	MinMaxHeap(size_t capacity) {
		if (capacity > 1)
			m_capacity = capacity;
		else
			m_capacity = 2;
		m_size = 1;
		m_data = new T[m_capacity];
	}
	T findMin() {
		return m_data[1];
	}
	T findMax() {
		return ((m_data[2] > m_data[3]) ? m_data[2] : m_data[3]);
	}
	int size() {
		return m_size;
	}
	bool isFull() {
		return (m_size == m_capacity);
	}
	void add(T value) {
		m_data[m_size] = value;
		if (m_size > 3) {
			if (isMinLevel(m_size / 2)) {
				if (m_data[m_size] < m_data[m_size / 2]) {
					swap(m_data[m_size], m_data[m_size / 2]);
					bubbleUp(m_size / 2, true);
				}
				else {
					bubbleUp(m_size, false);
				}
			}
			else {
				if (m_data[m_size] > m_data[m_size / 2]) {
					swap(m_data[m_size], m_data[m_size / 2]);
					bubbleUp(m_size / 2, false);
				}
				else {
					bubbleUp(m_size, true);
				}
			}
		}	
		m_size++;
	}
	friend ostream& operator<<(ostream&, const MinMaxHeap<T>& c) {
		int level = -1;
		for (int i = 1; i < c.m_size; ++i) {
			if (i == 1 || floor(log2(i)) > level) {
				cout << endl;
				for (int j = 0; j < c.m_capacity - 2 * i; ++j)
					cout << " ";
				++level;
			}
			cout << c.m_data[i];
			for (int j = 0; j < 2 * level; ++j)
				cout << " ";
		}
		return cout;
	}
	~MinMaxHeap() {
		delete[] m_data;
		m_data = nullptr;
		cout << "Destructor Ended";
	}
};


int main() {
	MinMaxHeap<int> mm1(64);
	mm1.add(8);
	mm1.add(71);
	mm1.add(41);
	cout << mm1 << endl;
	mm1.add(31);
	mm1.add(10);
	mm1.add(11);
	mm1.add(16);
	cout << mm1 << endl;
	mm1.add(46);
	mm1.add(51);
	mm1.add(31);
	mm1.add(21);
	mm1.add(13);
	cout << mm1 << endl;
	mm1.add(2);
	cout << "-----After Adding 2-----" << endl;
	cout << mm1 << endl;
	mm1.add(100);
	cout << "-----After Adding 100-----" << endl;
	cout << mm1 << endl;
	mm1.add(1);
	cout << "-----After Adding 1-----" << endl;
	cout << mm1 << endl;
	mm1.add(5);
	cout << "-----After Adding 5-----" << endl;
	cout << mm1 << endl;
	mm1.add(75);
	cout << "-----After Adding 75-----" << endl;
	cout << mm1 << endl;
	return 0;
}