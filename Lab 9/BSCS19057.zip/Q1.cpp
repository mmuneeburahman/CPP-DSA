#include <iostream>
using namespace std;

int levelnumber(int node) {
	return log2(node);
}
bool isMinLevel(int node) {
	return (levelnumber(node) % 2 == 0);
}
