#include <iostream>
using namespace std;

template <typename T>
void printArray(T arr[], int size) {
	for (int i = 0; i < size; ++i) {
		cout << arr[i] << " ";
	}
	cout << endl;
}

template <typename T>
int partition(T* arr, int s, int e) {
	int pivot = arr[s];
	int i = s;
	int j = e;
	while (i<j) {
		while (arr[i] >= pivot)++i;
		while (j>0 && arr[j] < pivot)--j;
		if(i<j)
		swap(arr[i], arr[j]);
	}
	swap(arr[j], arr[s]);
	return j;
}

int main() {
	int arr[6] = { 2, 6, 3, -1, 0, 5 };
	cout << "Array : ";
	printArray(arr, 6);
	int p = partition(arr, 0, 5);
	cout << "Partition index" << p << endl;
	cout << "Array is : ";
	printArray(arr, 6);
	cout << endl << "Conclusion # Array on the left of index" << p << " has greater intergers then " << arr[p] << "," << endl;
	cout << " and has smaller integers on the right" << endl << endl;
	return 0;
}