#include <iostream>
using namespace std;
template <typename T>
void printArray(T arr[], int size) {
	for (int i = 0; i < size; ++i) {
		cout << arr[i] << " ";
	}
	cout << endl;
}
template <typename T>
int partition(T* arr, int s, int e) {
	int pivot = arr[s];
	int i = s;
	int j = e;
	while (i<j) {
		while (arr[i] >= pivot)++i;
		while (j>0 && arr[j] < pivot)--j;
		if(i<j)
		swap(arr[i], arr[j]);
	}
	swap(arr[j], arr[s]);
	return j;
}
template <typename T>
void quicksort(T* arr, int s, int e) {
	if (e <= s)return;
	int p = partition(arr, s, e);
	cout << "Partition Function is Called for: ";
	printArray(arr + s, e - s + 1);
	quicksort(arr, s, p - 1);
	quicksort(arr, p + 1, e);
}

int main() {
	int arr[6] = { 2, 6, 3, -1, 0, 5 };
	char* a1 = new char[5];
	a1[0] = 'a', a1[1] = 'f', a1[2] = 'g', a1[3] = 'z', a1[4] = 'k';

	cout << "Integer Array Before QuickSort: ";
	printArray(arr, 6);
	quicksort(arr, 0, 5);
	cout << "Integer Array After QuickSort: ";
	printArray(arr, 6);

	cout << "Character Array Before QuickSort: ";
	printArray(a1, 5);
	quicksort(a1, 0, 4);
	cout << "Character Array After QuickSort: ";
	printArray(a1, 5);
	return 0;
}