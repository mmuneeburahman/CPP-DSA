#include <iostream>
using namespace std;
template <typename T>
void printArray(T arr[], int size) {
    for (int i = 0; i < size; ++i) {
        cout << arr[i] << " ";
    }
    cout << endl;
}
template <typename T>
void merge(T* arr, int ls, int le, int rs, int re) {
    int sizeL = le - ls+1;
    int sizeR = re - rs+1;

    //Creating Two Temprory Arrays;
    T* L, * R;
    L = new T[sizeL];
    R = new T[sizeR];

    //Initializing SubArrays;
    for (int i = ls; i <= le; ++i)
        L[i - ls] = arr[i];
    for (int i = rs; i <= re; ++i)
        R[i - rs] = arr[i];

    //initalizing index for Left, Right and Merged Array;
    int i = 0, j = 0, k = ls;
    while (i < sizeL && j < sizeR) {
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            ++i;
        }
        else {
            arr[k] = R[j];
            ++j;
        }
        ++k;
    }
    //Coping Remaining Left Array;
    while (i < sizeL)
        {
            arr[k] = L[i];
            i++;
            k++;
        }
    //Coping Remaining Right Array;
    while (j < sizeR)
        {
            arr[k] = R[j];
            j++;
            k++;
        }

    //Deallocating Heap Memory;
    delete[] L;
    delete[] R;
}
template <typename T>
void mergeSort(T* arr, int l, int r)
{
    if (l < r)
    {
        int m = l + (r - l) / 2;

        // Sort first and second halves 
        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);

        merge(arr, l, m, m+1, r);
    }
}

int main() {
    int arr[4] = { 2,4,0,-1 };
    int arr1[4] = { 1,2,3,4 };
    char* a1 = new char[5];
    a1[0] = 'a', a1[1] = 'z', a1[2] = 'y', a1[3] = 'b', a1[4] = 'm';

    cout << "Array 1 Before MergeSort: ";
    printArray(arr, 4);
    mergeSort(arr, 0, 3);
    cout << "Array 1 After MergeSort: ";
    printArray(arr, 4);

    cout << "Array 2 Before MergeSort: ";
    printArray(arr1, 4);
    mergeSort(arr1, 0, 3);
    cout << "Array 2 Before MergeSort: ";
    printArray(arr1, 4);

    cout << "Character Array 1 Before MergeSort: ";
    printArray(a1, 5);
    mergeSort(a1, 0, 4);
    cout << "Character Array 1 After MergeSort: ";
    printArray(a1, 5);
    return 0;
}