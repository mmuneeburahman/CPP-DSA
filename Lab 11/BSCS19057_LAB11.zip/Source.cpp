#include <iostream>
using namespace std;
template <typename T>
class SortedLinkedList {
	//template <typename T>
	struct node {
		T m_data;
		node* m_next;
	};
	node* m_head;
public:
	SortedLinkedList() {
		m_head = nullptr;
	}
	SortedLinkedList(T headValue) {
		m_head = new node;
		m_head.m_data = headValue;
		m_head.m_next = nullptr;
	}
	void add(T value) {
		node* temp;
		temp = m_head;
		if (temp == nullptr) {
			m_head = new node;
			m_head->m_data = value;
			m_head->m_next = nullptr;
		}
		else {
			while (temp->m_next != nullptr && value > temp->m_next->m_data) {
				temp = temp->m_next;
			}
			if (temp == m_head && m_head->m_data>value) //Node Added on Head.
			{
				m_head = new node;
				m_head->m_data = value;
				m_head->m_next = temp;
			}
			else if (temp->m_next != nullptr) { //Node Added in the middle
				node* addedNode = new node;
				addedNode->m_data = value;
				addedNode->m_next = temp->m_next;
				temp->m_next = addedNode;
			}
			else { //Node added in the last
				temp->m_next = new node;
				temp->m_next->m_data = value;
				temp->m_next->m_next = nullptr;
			}
		}


	}
	void reverseSortedOrder() {
		node* back = m_head;
		node* present = m_head->m_next;
		node* ahead;
		(m_head->m_next!=nullptr)?(ahead = m_head->m_next->m_next):(ahead = nullptr);
		//m_head->m_next = nullptr;
		if (present != nullptr) {
			back->m_next = nullptr;
			present->m_next = back;
			while (ahead != nullptr) {
				back = present;
				present = ahead;
				ahead = ahead->m_next;
				present->m_next = back;
			}
			m_head = present;
		}
	}
	friend ostream& operator<<(ostream& cout, const SortedLinkedList<T>& l) {
		node* temp;
		temp = l.m_head;
		if (temp != nullptr) {
			cout << temp->m_data;
			while (temp->m_next != nullptr) {
				temp = temp->m_next;
				cout << "-->" << temp->m_data;
			}
			cout << " :)";
		}
		else {
			cout << "Empty! :)";
		}
		return cout;
	}
	void eraseFront() {
		if (m_head != nullptr) {
			node* temp;
			temp = m_head;
			temp = temp->m_next;
			if (m_head != nullptr) {
				delete m_head;
			}
			m_head = temp;
		}

	}
	bool isPresent(T value) {
		return (searchIndex(value) != -1);
	}
	int searchIndex(T value) {
		node* temp;
		temp = m_head;

		int i = 0;
		while (temp != nullptr && temp->m_data != value) {
			temp = temp->m_next;
			++i;
		}
		if (temp == nullptr)return -1;
		else return i;

	}
};
int main() {
	SortedLinkedList<char> ci;
	ci.add('b');
	cout << "b added:" << ci << endl;
	ci.add('z');
	cout << "z added: " << ci << endl;
	ci.add('f');
	cout << "f added: " << ci << endl;
	ci.add('a');
	cout << "a added: " << ci << endl;
	ci.reverseSortedOrder();
	cout << "Reverse Order: " << ci << endl;

}
int main1() {
	SortedLinkedList<int> li;
	li.add(10);
	li.add(5);
	li.add(8);
	li.add(20);
	cout << li << endl;
	int i = 4;
	cout << endl << endl;
	while (i != -1) {
		li.eraseFront();
		cout << li << endl;
		--i;
	}
	cout << endl << endl;
	for (int i = 1; i <= 5; ++i) {
		li.add((i-5) * (i-5));
		cout << li << endl;
	}
	cout << "Index of 8 is " << li.searchIndex(8) << endl;
	cout << "Index of 16 is " << li.searchIndex(16) << endl;
	cout << "Index of 64 is " << li.searchIndex(64) << endl;
	return 0;
	return 0;
}
int main2() {

	SortedLinkedList<int> li;
	cout << "Adding 1st value." << endl;
	li.add(10);
	li.reverseSortedOrder();
	cout << li << endl;
	cout << "Remain same after reverse sorted order, becuase contain one value." << endl;
	
	cout << endl << "Adding 2nd value." << endl;
	li.add(5);
	cout << "After adding 2nd value : " << li << endl;
	
	li.reverseSortedOrder();
	cout << "Reverse Oder: ";
	cout << li << endl;
	li.reverseSortedOrder();

	cout << endl << "Going back to sorted Order and adding 3rd value." << endl;
	li.add(8);
	cout << "Sorted Order: "<<li << endl;
	li.reverseSortedOrder();
	cout << "Reverse Order: " << li << endl;
	li.reverseSortedOrder();
	
	cout << endl << "Going back to sorted Order and adding 2 more values." << endl;
	li.add(20);
	li.add(50);
	cout << "Sorted Order: "<<li << endl;
	li.reverseSortedOrder();
	cout <<"Reverse Order: "<< li << endl;
	return 0;
}