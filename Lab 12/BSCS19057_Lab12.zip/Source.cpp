#include <iostream>
#include <fstream>
#include <conio.h>
#include <algorithm>

using namespace std;
// YOU MUST DEFINE SIZE FOR THESE FUNCTIONS TO WORK

#define A 54059 /* a prime */
#define B 76963 /* another prime */
#define C 86969 /* yet another prime */
#define FIRSTH 37 /* also prime */

class BloomFilter {
	int SIZE;
	int* m_data;
	int hash1(char* s)
	{
		unsigned h = FIRSTH;
		while (*s) {
			h = (h * A) ^ (s[0] * B);
			s++;
		}
		return h % SIZE;
	}
	int hash2(string word)
		// POST: the index of entry is returned
	{
		int sum = 0;
		for (int k = 0; k < word.length(); k++)
			sum = sum + int(word[k]);
		return  sum % SIZE;
	}
	int hash3(string word)
	{
		int seed = 131;
		unsigned long hash = 0;
		for (int i = 0; i < word.length(); i++)
		{
			hash = (hash * seed) + word[i];
		}
		return hash % SIZE;
	}
public:
	//Default Constructor;
	BloomFilter():BloomFilter(150) {}
	BloomFilter(size_t size) {
		SIZE = size;
		m_data = new int[SIZE];
		for (int i = 0; i < SIZE; ++i)
			m_data[i] = 0;
	}
	//Select the HashFunction with Fun* and return Index;
	int returnIndex(char*s, int caseNo) {
		int(BloomFilter:: * Present[])(string) =
		{
			&BloomFilter::hash2,
			&BloomFilter::hash3 };
		return (caseNo == 1) ? (hash1(s)) : ((this->*Present[caseNo - 2])(s));
	}
	bool IsPresent(char *s, size_t caseNo) {
		
		return m_data[returnIndex(s, caseNo)];
	}
	void addToBF(char* s, size_t caseNo) {
		++m_data[returnIndex(s, caseNo)];
	}
	~BloomFilter() {
		cout << "Destructor called";
	}
};
int main() {
	ifstream rdr("passage.txt");
	string word;
	int testCases = 3;
	BloomFilter* data = new BloomFilter[testCases];
	int wordcounter = 1;
	for (int i = 1; i <= 3; ++i) {
		cout << "\t\t<-----Case No: " << i << "------>" << endl;
		while (rdr) {
			rdr >> word;
			char* cstr;
			cstr = &word[0];
			bool present = data[i - 1].IsPresent(cstr, i);
			if (!present) {
				cout << wordcounter << ".  " << cstr << endl;
				++wordcounter;
			}
			data[i - 1].addToBF(cstr, i);
		}
		rdr.clear();
		rdr.seekg(0);
		wordcounter = 1;
	}
	return 0;
}