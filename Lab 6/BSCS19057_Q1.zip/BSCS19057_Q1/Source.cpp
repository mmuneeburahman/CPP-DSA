#include <iostream>
#include <string>
#include <fstream>
using namespace std;

#define A 54059 /* a prime */
#define B 76963 /* another prime */
#define C 86969 /* yet another prime */
#define FIRSTH 37 /* also prime */

int hash2(string word)
// POST: the index of entry is returned
{
	int sum = 0;
	for (int k = 0; k < word.length(); k++)
		sum = sum + int(word[k]);
	return  sum % 110;
}
int hash3(string word)
{
	int seed = 131;
	unsigned long hash = 0;
	for (int i = 0; i < word.length(); i++)
	{
		hash = (hash * seed) + word[i];
	}
	return hash % 110;
}

struct ppair {
	string key;
	string value;
	ppair(string k, string v) {
		key = k;
		value = v;
	}
};
struct HashTable {
	size_t size;
	ppair** data;
};

void additem(string key, string value, HashTable& T) {
	int index = hash2(key);
	//Loop Find the EMPTY Space or check whether key is already found,
	//If no empty space is found, the value is inserted at the end.
	while (index<110 && T.data[index] != nullptr && T.data[index][0].key != key)
		++index;
	if (index == 110)--index;
	if (T.data[index] == nullptr)
		T.data[index] = new ppair(key, value);
	else
		T.data[index][0].value = value;
}
//Search The Index..
int search(string key, HashTable& T) {
	int index = hash2(key);
	while (index<110 && T.data[index] != nullptr) {
		if (T.data[index][0].key == key)
			return index;
		else
			++index;
	}
	return -1;
}
//Check the value if it is found...
void testfunction(HashTable& T) {
	ifstream rdr("test.txt");
	for (int i = 0; i < 110; ++i) {
		string key;
		getline(rdr, key, '\n');
		if (search(key, T))
			cout << "Found" << endl;
		else
			cout << "Not Found" << endl;
	}
}
int main() {
	HashTable T1;
	T1.size = 110;
	T1.data = new ppair * [T1.size];
	for (int i = 0; i < T1.size; ++i)
		T1.data[i] = nullptr;
	string key;
	string value;
	ifstream rdr("data.txt");
	for (int i = 0; i < T1.size; ++i) {
		getline(rdr, key, '\t');
		getline(rdr, value, '\n');
		cout << key << " " << value << endl;
		additem(key, value, T1);
	}
	testfunction(T1);
	return 0;
}
