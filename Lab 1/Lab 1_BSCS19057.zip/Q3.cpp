#include <iostream>
using namespace std;

//Take Correct NUMBER Input From the User
template <typename T>
void takeInput(T& variable, const string& Message) {
	cin >> variable;
	while (cin.fail()) {
		cin.clear();
		cin.ignore(INT_MAX, '\n');
		cout << Message;
		cin >> variable;
	}
}
//A function to Print Dynamic Array.
template <typename T>
void printPointersArray(T* arr, int size) {
	cout << "{ ";
	for (int i = 0; i < size; ++i)
		cout << arr[i] << " ";
	cout << "}";
}
void performTask(double* arr, int size, char symbol) {
	if (symbol == 'h' || symbol == 'H') {
		for (int i = 0; i < size; ++i) {
			arr[i] = arr[i] / 2;
		}
	}
	else {
		for (int i = 0; i < size; ++i) {
			arr[i] = arr[i] * 2;
		}
	}
}
int main() {
	int size = 0;
	double* arr;
	char choice;
	cout << "Size Of Your Input : ";
	cin >> size;
	arr = new double[size];
	double num;
	cout << "Enter Numbers : ";
	for (int i = 0; i < size; ++i) {
		takeInput(num, "Enter Number : ");
		arr[i] = num;
	}
	printPointersArray(arr, size);
	cout << "\n\nDo you to HALF(h/H) or DOUBLE(d/D) your array....!";
	cin >> choice;
	while (choice != 'h' && choice != 'H' && choice != 'd' && choice != 'D') {
		cout << "Enter (h/H/d/D) : ";
		cin >> choice;
	}

	//Buffer Clear in Case of String.
	cin.ignore(INT_MAX, '\n');

	performTask(arr, size, choice);
	cout << "\n\nAfter Performing the Operation" << endl;
	cout << ":-----------------------:" << endl;
	printPointersArray(arr, size);
	return 0;
}