#include <iostream>
#include <limits>
using namespace std;

int main() {
	char C;
	int num;
	cout << "User input:" << endl;
	cout << "Please enter Character C: ";
	cin >> C;

	//Clearing the buffer in case User Inputs a String.
	cin.ignore(INT_MAX, '\n');

	cout << "Please Enter Number :";
	cin >> num;

	//Checking if the input from the user is not a NUMBER.
	while (cin.fail()) {
		cin.clear();
		cin.ignore(INT_MAX, '\n');
		cout << "Please Enter Number : ";
		cin >> num;
	}
	cout << "Output: ";
	for (int i = 0; i < num; ++i)
		cout << C;

	return 0;
}