#include <iostream>
using namespace std;

//A function used to create rows x cols Dynamic Array.

double** createDynamic2DArray(const size_t rows, const size_t cols) {
	double** arr = new double* [rows];
	for (int i = 0; i < rows; ++i)
		arr[i] = new double[cols];
	return arr;
}

//Printing Dynamic 2D Array Function.
template <typename T>
void printDynamic2DArray(T** arr, int rows, int cols) {

	for (int i = 0; i < rows; ++i) {
		for (int j = 0; j < cols; ++j) {
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
}

//Take Correct NUMBER Input From the User
template <typename T>
void takeInput(T& variable, const string& Message) {
	cin >> variable;
	while (cin.fail()) {
		cin.clear();
		cin.ignore(INT_MAX, '\n');
		cout << Message;
		cin >> variable;
	}
}

void performTask(double** arr, int rows, int cols, char symbol) {
	if (symbol == 'h' || symbol == 'H') {
		for (int r = 0; r < rows; ++r) {
			for(int c = 0; c<cols; ++c)
			arr[r][c] = arr[r][c] / 2;
		}
	}
	else {
		for (int r = 0; r < rows; ++r) {
			for (int c = 0; c < cols; ++c)
				arr[r][c] = arr[r][c] * 2;
		}
	}
}
int main() {
	int rows, cols;
	char choice;
	cout << "Enter the Dimensions Of 2D Dynamic Array.." << endl;
	cout << "Enter Number Of Rows : ";
	takeInput(rows, "Enter Number Of Rows : ");
	cout << "Enter Number of Cols : ";
	takeInput(cols, "Enter Number of Cols : ");
	double** arr = createDynamic2DArray(rows, cols);
	/*intializeAllValueWith(arr, DIM, 0);*/
	double num;
	cout << "You have to Enter " << rows * cols << " numbers...!!" << endl;
	cout << "Enter Numbers : ";
	for (int r = 0; r < rows; ++r) {
		for (int c = 0; c < cols; ++c) {
			takeInput(num, "Enter  Numbers : ");
			arr[r][c] = num;
		}
	}
	//Buffer Clear in Case of String.
	cin.ignore(INT_MAX, '\n');
	printDynamic2DArray(arr, rows, cols);

	cout << "\n\nDo you to HALF(h/H) or DOUBLE(d/D) your array....!";
	cin >> choice;
	while (choice != 'h' && choice != 'H' && choice != 'd' && choice != 'D') {
		cout << "Enter (h/H/d/D) : ";
		cin >> choice;
	}

	//Buffer Clear in Case of String.
	cin.ignore(INT_MAX, '\n');

	performTask(arr, rows,cols, choice);
	cout << "\n\nAfter Performing the Operation" << endl;
	cout << ":-----------------------:" << endl;
	printDynamic2DArray(arr, rows, cols);
	return 0;

}