#include <iostream>
using namespace std;
//A function used to create rows x cols Dynamic Array.
int** createDynamic2DArray(const size_t rows, const size_t cols) {
	int** arr = new int* [rows];
	for (int i = 0; i < rows; ++i)
		arr[i] = new int[cols];
	return arr;
}

//Testing Function To initalize the Dynamic Array
void intializeAllValueWith(int** arr, const size_t DIM, int value) {
	for (int i = 0; i < DIM; ++i) {
		for (int j = 0; j < DIM; ++j) {
			arr[i][j] = value;
		}
	}
}

//Printing Dynamic 2D Array Function.
template <typename T>
void printDynamic2DArray(T** arr, int rows, int cols) {
	
	for (int i = 0; i < rows; ++i) {
		for (int j = 0; j < cols; ++j) {
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
}

//Take Correct NUMBER Input From the User
template <typename T>
void takeInput(T& variable,const string& Message) {
	cin >> variable;
	while (cin.fail()) {
		cin.clear();
		cin.ignore(INT_MAX, '\n');
		cout << Message;
		cin >> variable;
	}
}
int main() {
	const size_t DIM = 5;
	int** arr = createDynamic2DArray(DIM, DIM);
	/*intializeAllValueWith(arr, DIM, 0);*/
	int num;
	cout << "You have to Enter " << DIM * DIM << " numbers...!!" << endl;
	cout << "Enter Numbers : ";
	for (int i = 0; i < DIM; ++i) {
		for (int j = 0; j < DIM; ++j) {
			takeInput(num, "Enter  Numbers : ");
			arr[i][j] = num;
		}
	}
	cin.ignore(INT_MAX, '\n');
	printDynamic2DArray(arr, DIM, DIM);

	return 0;

}