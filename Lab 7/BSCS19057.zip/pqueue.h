#pragma once
#include <iostream>
#include <list>
using namespace std;

template <typename T>
class pqueue
{
	struct element {
		T m_value;
		int m_priority;
		element(T value, int priority) {
			m_value = value;
			m_priority = priority;
		}
		friend ostream& operator<<(ostream&, const element& e) {
			cout << e.m_value << " , " << e.m_priority;
			return cout;
		}
	};
	int m_capacity;
	int m_priorityCounter;
	list<element> m_data;
	int findPosition(int priority) {
		int i = 0;
		for (auto it = m_data.begin(); it != m_data.end() && it->m_priority<50; ++it) {
			if (it->m_priority > priority)
				return i;
			else if (it->m_priority == priority)
				return -1;
		}
	}
public:
	pqueue(int size) {
		m_capacity = size;
		m_priorityCounter = 50;
	}
	void enque(T value) {
		if(m_data.size()!=m_capacity){
			m_data.push_back(element(value, m_priorityCounter));
			++m_priorityCounter;
		}
	}
	void enque(T value, int priority) {
		if (m_data.size() != m_capacity) {
			if (priority < 50) {
				typename list<element>::iterator it = m_data.begin();
				int i = findPosition(priority);
				if (i != -1) {
					advance(it, i);
					m_data.insert(it, element(value, priority));
				}
			}
			else {
				enque(value);
			}
		}
	}
	void deque() {
		m_data.pop_front();
	}
	int size()const {
		return m_data.size();
	}
	friend ostream& operator<<(ostream&, const pqueue& pq) {
		//list <int> :: iterator it;
		for (auto it = pq.m_data.begin(); it != pq.m_data.end(); ++it)
			cout << "(" <<*it<< ")" << " ";
		return cout;
	}
};
