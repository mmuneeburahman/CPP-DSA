#include <iostream>
#include "pqueue.h"
using namespace std;


int main() {
	
	pqueue<int>pq(6);
	for (int i = 0; i < 5; ++i)
		pq.enque(i + i);
	cout << pq << endl;
	pq.deque();
	pq.deque();
	cout << pq << endl;
	pq.enque(10, 10);
	pq.enque(1, 15);
	pq.enque(5, 15);
	cout << pq << endl;
	pq.deque();
	pq.deque();
	cout << pq << endl;
	return 0;
}