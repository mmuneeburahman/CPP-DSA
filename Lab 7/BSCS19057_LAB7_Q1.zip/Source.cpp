#include <iostream>
#include "Stack.h"
using namespace std;
 
int main() {
	Stack<int>a(5);
	for (int i = 0; i < 5; ++i)
		a.push(i * i * i);
	cout << "a : "<<a << endl;
	for (int i = 0; i < 10; ++i)
		a.pop();
	cout << "a : " << a << endl;
	a.push(1000);
	cout << "a : " << a << endl;


	cout << endl << endl;
	Stack<char>b(5);
	for (int i = 0; i < 5; ++i)
		b.push(65 + (i * 5));
	cout <<"b : "<< b << endl;
	for (int i = 0; i < 5; ++i)
		b.pop();
	cout << "b : " << b << endl;
	b.push(100);
	cout << "b : " << b << endl;
	return 0;
}
