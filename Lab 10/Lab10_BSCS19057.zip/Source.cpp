#include <iostream>
using namespace std;
template <typename T>
class llist {
	//template <typename T>
	struct node{
		T m_data;
		node* m_next;
	};
	node* m_head;
public:
	llist() {
		m_head = nullptr;
	}
	llist(T headValue) {
		m_head = new node;
		m_head.m_data = headValue;
		m_head.m_next = nullptr;
	}
	void add(T value) {
		node* temp;
		temp = m_head;
		if (temp == nullptr) {
			m_head = new node;
			m_head->m_data = value;
			m_head->m_next = nullptr;
		}
		else {
			while (temp->m_next != nullptr) {
				temp = temp->m_next;
			}
			temp->m_next = new node;
			temp->m_next->m_data = value;
			temp->m_next->m_next = nullptr;
		}
		
		
	}
	friend ostream& operator<<(ostream& cout, const llist<T>& l) {
		node* temp;
		temp = l.m_head;
		if (temp != nullptr) {
			cout << temp->m_data;
			while (temp->m_next != nullptr) {
				temp = temp->m_next;
				cout << "-->" << temp->m_data;
			}
			cout << " :)";
		}
		else {
			cout << "Empty! :)";
		}
		return cout;
	}
	void eraseFront() {
		if (m_head != nullptr) {
			node* temp;
			temp = m_head;
			temp = temp->m_next;
			if (m_head != nullptr) {
				delete m_head;
			}
			m_head = temp;
		}
		
	}
	int searchIndex(T value) {
		node* temp;
		temp = m_head;
		
		int i = 0;
		while (temp != nullptr && temp->m_data != value) {
			temp = temp->m_next;
			++i;
		}
		if (temp == nullptr)return -1;
		else return i;
		
	}
};

int main() {

	llist<int> li;
	li.add(10);
	li.add(200);
	li.add(3000);
	li.add(40000);
	cout << li << endl;
	int i = 4;
	cout << endl << endl;
	while (i != -1) {
		li.eraseFront();
		cout << li << endl;
		--i;
	}
	cout << endl << endl;
	for (int i = 1; i <= 5; ++i) {
		li.add(i * i * i);
		cout << li << endl;
	}
	cout << "Index of 8 is " << li.searchIndex(8) << endl;
	cout << "Index of 16 is " << li.searchIndex(16) << endl;
	cout << "Index of 64 is " << li.searchIndex(64) << endl;
	return 0;
}