#include <iostream>
using namespace std;

template <typename T>
class SortedArray {
	size_t m_SIZE;
	size_t m_CAPACITY;
	T* m_array;
	//Expanding Array Dynamically
	void expandArray() {
		m_CAPACITY = 2 * m_CAPACITY;
		T* newArray = new T[m_CAPACITY];
		for (int i = 0; i < m_SIZE; ++i) {
			newArray[i] = m_array[i];
		}
		delete[] m_array;
		m_array = newArray;
	}

	void insertionSort() {
		int j = m_SIZE-1;
		while (j - 1 >= 0 && m_array[j] < m_array[j - 1]) {
			swap(m_array[j], m_array[j - 1]);
			--j;
		}
	}
	//Testing Function
	void printArray(T* arr, int size) {
		for (int i = 0; i < size; i++) {
			cout << arr[i] << " ";
		}
		cout << endl;
	}
public:
	SortedArray() :m_SIZE(0), m_CAPACITY(1) {
		m_array = new T[m_CAPACITY];
	}
	void insertInSortedOrder(T val) {
		if (m_SIZE == m_CAPACITY) {
			expandArray();
			m_array[m_SIZE] = val;
		}
		else
			m_array[m_SIZE] = val;
		++m_SIZE;
		insertionSort();
	}
	friend ostream& operator<<(ostream&, const SortedArray<T>& arr) {
		for (int i = 0; i < arr.m_SIZE; ++i)
			cout << arr.m_array[i] << " ";
		return cout;
	}
	int search(T val) {
		for (int i =0; i<m_SIZE; ++i)
			if (m_array[i] == val)
				return i;
		return -1;
	}
	int getSize() {
		return m_SIZE;
	}
	void deleteVal(T val) {
		int index = search(val);
		if (index != -1) {
			int j = index;
			while (j + 1 < m_SIZE) {
				swap(m_array[j], m_array[j + 1]);
				++j;
			}
			--m_SIZE;
		}
		
	}
};
int main() {
	cout << "<----TESTING int ARRAY---->" << endl;
	SortedArray<int> intArray;
	intArray.insertInSortedOrder(10);
	cout << intArray << endl;
	intArray.insertInSortedOrder(0);
	cout << intArray << endl;
	intArray.insertInSortedOrder(10);
	cout << intArray << endl;
	intArray.insertInSortedOrder(-5);
	cout << intArray << endl;
	cout << "Searching 20 : ";
	if (intArray.search(20) != -1)
		cout << "Found" << endl;
	else
		cout << "Not Found" << endl;
	cout << "Searching 3 : ";
	if (intArray.search(3) != -1)
		cout << "Found" << endl;
	else
		cout << "Not Found" << endl;
	intArray.deleteVal(10);
	cout << "After Deleting 10 : " << intArray << endl;
	intArray.deleteVal(0);
	cout << "After Deleting 0 : " << intArray << endl;
	intArray.insertInSortedOrder(50);
	cout << "After inserting 50 : " << intArray<<endl;
	intArray.insertInSortedOrder(25);
	cout << "After inserting 25 : " << intArray << endl;
	cout << endl << endl << endl;


	cout << "<-----TESTING char ARRAY---->" << endl;
	SortedArray<char> charArray;
	charArray.insertInSortedOrder('b');
	cout << charArray << endl;
	charArray.insertInSortedOrder('m');
	cout << charArray << endl;
	charArray.insertInSortedOrder('c');
	cout << charArray << endl;
	charArray.insertInSortedOrder('f');
	cout << charArray << endl;
	cout << "Searching 'm' : ";
	if (charArray.search('m') != -1)
		cout << "Found" << endl;
	else
		cout << "Not Found" << endl;
	cout << "Searching 'z' : ";
	if (charArray.search('z') != -1)
		cout << "Found" << endl;
	else
		cout << "Not Found" << endl;
	charArray.deleteVal('m');
	cout << "After Deleting 'm' : " << charArray << endl;
	charArray.deleteVal('b');
	cout << "After Deleting 'b': " << charArray << endl;
	charArray.insertInSortedOrder('f');
	cout << "After inserting 'f' : " << charArray << endl;
	charArray.insertInSortedOrder('p');
	cout << "After inserting 'p' : " << charArray << endl;

	return 0;
}